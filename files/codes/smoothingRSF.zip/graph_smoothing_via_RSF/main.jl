using RandomForests

using ImageView, TestImages, Gtk.ShortNames, Images, ImageMagick, ImageQualityIndexes
using DelimitedFiles
using LightGraphs
using StatsBase
using Plots
using Clustering
using BenchmarkTools
using SparseArrays
plotly()

include("utils.jl")


## Figure 1 (image denoising)
begin
    imname = "lake_gray"
    im = imresize(testimage(imname), 64, 64)
    im = Float64.(Gray.(im))
    nx = size(im,1)
    ny = size(im,2)
    rs = (v) -> reshape(v,nx,ny)
    G = LightGraphs.grid([nx,ny])
    im = im[:]

    gamma = .20

    n_noisy_replicates = 100
    Q = collect(0.01:0.3:4.)
    NREP = [1, 5, 20]
    PSNR_y = zeros(n_noisy_replicates)
    PSNR_xhat = zeros(length(Q), n_noisy_replicates)
    PSNR_xtilde = zeros(length(Q), length(NREP), n_noisy_replicates)
    PSNR_xbar = zeros(length(Q), length(NREP), n_noisy_replicates)

    Y = repeat(im', outer=n_noisy_replicates)' + randn((length(im), n_noisy_replicates))*gamma
    for i = 1:n_noisy_replicates
        PSNR_y[i] = ImageQualityIndexes.psnr(Y[:,i], im)
    end

    for qq = 1:length(Q)
        global Xhat, Xbar, Xtilde
        q = Q[qq]
        Xhat = smooth(G,q,Y)
        for i = 1:n_noisy_replicates
            PSNR_xhat[qq, i] = ImageQualityIndexes.psnr(Xhat[:,i], im)
        end
        for nn = length(NREP):-1:1
            nrep = NREP[nn]
            print("q=$q and nrep=$nrep \n")
            Ybar = repeat(mean(Y, dims=1), outer=size(Y,1))
            Δ = Y - Ybar
            Xtilde = Ybar + smooth_rf(G,q,Δ; variant=1,nrep=nrep).est
            Xbar = Ybar + smooth_rf(G,q,Δ; variant=2,nrep=nrep).est
            for i = 1:n_noisy_replicates
                PSNR_xtilde[qq, nn, i] = ImageQualityIndexes.psnr(Xtilde[:,i], im)
                PSNR_xbar[qq, nn, i] = ImageQualityIndexes.psnr(Xbar[:,i], im)
            end
        end
    end

    ## figure PSNR_vs_q
    plot(Q, mean(PSNR_xhat, dims=2), line=(:solid,:black,6), label="x̂")
    plot!(Q, mean(PSNR_xtilde, dims=3)[:,2], line=(:dot,6), label="x̃, N=$(NREP[2])")
    plot!(Q, mean(PSNR_xtilde, dims=3)[:,3], line=(:dot,6), label="x̃, N=$(NREP[3])")
    plot!(Q, mean(PSNR_xbar, dims=3)[:,2], line=(:solid,6), label="x̄, N=$(NREP[2])")
    plot!(Q, mean(PSNR_xbar, dims=3)[:,3], line=(:solid,6), label="x̄, N=$(NREP[3])")
    hline!([mean(PSNR_y)], line=(:dashdot,6), label="y")
    plot!(xlabel = "q", ylabel = "PSNR", yticks = [14,18])
    plot!(guidefontsize=24, tickfont=24, legendfont=24)

    ## image denoising examples
    q = 1.
    Xhat = smooth(G,q,Y)
    nrep=1
    Ybar = repeat(mean(Y, dims=1), outer=size(Y,1))
    Δ = Y - Ybar
    Xtilde = Ybar + smooth_rf(G,q,Δ; variant=1,nrep=nrep).est
    Xbar = Ybar + smooth_rf(G,q,Δ; variant=2,nrep=nrep).est
    y = Y[:,1]
    xhat = Xhat[:,1]
    xtilde = Xtilde[:,1]
    xbar = Xbar[:,1]
    y[y.<0] .= 0.; y[y.>1] .= 1.
    xhat[xhat.<0] .= 0.; xhat[xhat.>1] .= 1.
    xtilde[xtilde.<0] .= 0.; xtilde[xtilde.>1] .= 1.
    xbar[xbar.<0] .= 0.; xbar[xbar.>1] .= 1.
    save("orig.jpg", rs(im))
    save("noisy.jpg", rs(y))
    save("xhat_q=$q.jpg", rs(xhat))
    save("xtilde_q=$(q)_nrep=$nrep.jpg", rs(xtilde))
    save("xbar_q=$(q)_nrep=$nrep.jpg", rs(xbar))
    nrep=20
    Ybar = repeat(mean(Y, dims=1), outer=size(Y,1))
    Δ = Y - Ybar
    Xtilde = Ybar + smooth_rf(G,q,Δ; variant=1,nrep=nrep).est
    Xbar = Ybar + smooth_rf(G,q,Δ; variant=2,nrep=nrep).est
    xtilde = Xtilde[:,1]
    xbar = Xbar[:,1]
    y[y.<0] .= 0.; y[y.>1] .= 1.
    xhat[xhat.<0] .= 0.; xhat[xhat.>1] .= 1.
    xtilde[xtilde.<0] .= 0.; xtilde[xtilde.>1] .= 1.
    xbar[xbar.<0] .= 0.; xbar[xbar.>1] .= 1.
    save("xtilde_q=$(q)_nrep=$nrep.jpg", rs(xtilde))
    save("xbar_q=$(q)_nrep=$nrep.jpg", rs(xbar))
end

## Figure 2 (example on small SBM: "tight communities example")
begin
    n = 3000 #number of nodes
    k = 2 #number of classes
    # "strong block structure":
    s = 34.5
    easiness = 4.7
    #look into the code of generate_SBM to check that indeed this set of parameters corresponds to pin=0.02 and pout=0.003

    M = [20, 50, 100, 200] # number of labeled nodes per block
    sigma = 0. # which Laplacian to use for smoothness
    #MU = [.001, .01, .1, 1., 10.] # trade-off
    MU = [1.]
    NREP = [50, 100, 500] # number of RSF replicates for estimators
    ntrials = 10
    perf_exact = zeros(length(MU), length(M), ntrials)
    perf_tilde = zeros(length(MU), length(M), length(NREP), ntrials)
    perf_bar = zeros(length(MU), length(M), length(NREP), ntrials)
    exaequo_t = zeros(length(MU), length(M), length(NREP), ntrials)
    exaequo_b = zeros(length(MU), length(M), length(NREP), ntrials)

    for mmu=1:length(MU)
        mu = MU[mmu]
        for mm=1:length(M)
            m = M[mm]
            for nn=1:ntrials
                G, gr_truth = generate_SBM(n, k, s, easiness)
                Y = generate_Y(n, k, m)
                est_cl_exact, _ = ssl(G,Y,mu,sigma,method="exact")
                perf_exact[mmu, mm, nn] = randindex(gr_truth, est_cl_exact)[1]
                for nnr=1:length(NREP)
                    nrep = NREP[nnr]
                    print("mu=$mu and m=$m and nn=$nn and nrep=$nrep\n")
                    est_cl_tilde, exaequo_t[mmu, mm, nnr, nn] = ssl(G,Y,mu,sigma,method="xtilde",nrep=nrep)
                    perf_tilde[mmu, mm, nnr, nn] = randindex(gr_truth, est_cl_tilde)[1]
                    est_cl_bar, exaequo_b[mmu, mm, nnr, nn] = ssl(G,Y,mu,sigma,method="xbar", nrep=nrep)
                    perf_bar[mmu, mm, nnr, nn] = randindex(gr_truth, est_cl_bar)[1]
                end
            end
        end
    end

    mmu=1
    plot(M, mean(perf_exact[mmu,:,:], dims=2), line=(:solid,:black,6), label="x̂")
    nnr=1;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="x̃ N=$(NREP[nnr])")
    nnr=2;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="x̃ N=$(NREP[nnr])")
    nnr=3;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="x̃ N=$(NREP[nnr])")
    nnr=1;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="x̄ N=$(NREP[nnr])")
    nnr=2;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="x̄ N=$(NREP[nnr])")
    nnr=3;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="x̄ N=$(NREP[nnr])")
    plot!(xlabel = "m", ylabel = " ARI")
    plot!(guidefontsize=24, tickfont=24, legendfont=24, ylims=[0, 1], xlims=[0, maximum(M)+10], yticks = [0, 0.3,0.6,0.9])
end

## Figure 2 (example on small SBM: "fuzzy communities example")
begin
    n = 3000 #number of nodes
    k = 2 #number of classes
    # "fuzzy structure":
    s = 19.5 #average degree
    easiness = 2.1 #the larger this parameter, the clearer the SBM's block structure
    #look into the code of generate_SBM to check that indeed this set of parameters corresponds to pin=0.01 and pout=0.003

    M = [20, 50, 100, 200] # number of labeled nodes per block
    sigma = 0. # which Laplacian to use for smoothness
    #MU = [.001, .01, .1, 1., 10.] # trade-off
    MU = [1.]
    NREP = [50, 100, 500] # number of RSF replicates for estimators
    ntrials = 10
    perf_exact = zeros(length(MU), length(M), ntrials)
    perf_tilde = zeros(length(MU), length(M), length(NREP), ntrials)
    perf_bar = zeros(length(MU), length(M), length(NREP), ntrials)
    exaequo_t = zeros(length(MU), length(M), length(NREP), ntrials)
    exaequo_b = zeros(length(MU), length(M), length(NREP), ntrials)

    for mmu=1:length(MU)
        mu = MU[mmu]
        for mm=1:length(M)
            m = M[mm]
            for nn=1:ntrials
                G, gr_truth = generate_SBM(n, k, s, easiness)
                Y = generate_Y(n, k, m)
                est_cl_exact, _ = ssl(G,Y,mu,sigma,method="exact")
                perf_exact[mmu, mm, nn] = randindex(gr_truth, est_cl_exact)[1]
                for nnr=1:length(NREP)
                    nrep = NREP[nnr]
                    print("mu=$mu and m=$m and nn=$nn and nrep=$nrep\n")
                    est_cl_tilde, exaequo_t[mmu, mm, nnr, nn] = ssl(G,Y,mu,sigma,method="xtilde",nrep=nrep)
                    perf_tilde[mmu, mm, nnr, nn] = randindex(gr_truth, est_cl_tilde)[1]
                    est_cl_bar, exaequo_b[mmu, mm, nnr, nn] = ssl(G,Y,mu,sigma,method="xbar", nrep=nrep)
                    perf_bar[mmu, mm, nnr, nn] = randindex(gr_truth, est_cl_bar)[1]
                end
            end
        end
    end

    mmu=1
    plot(M, mean(perf_exact[mmu,:,:], dims=2), line=(:solid,:black,6), label="")
    nnr=1;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="")
    nnr=2;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="")
    nnr=3;plot!(M, mean(perf_tilde[mmu,:,nnr,:], dims=2), line=(:dot,6), label="")
    nnr=1;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="")
    nnr=2;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="")
    nnr=3;plot!(M, mean(perf_bar[mmu,:,nnr,:], dims=2), line=(:solid,6), label="")
    plot!(xlabel = "m", ylabel = " ARI")
    plot!(guidefontsize=24, tickfont=24, legendfont=24, ylims=[0, 1], xlims=[0, maximum(M)+10], yticks = [0, 0.3,0.6,0.9])
end

## computation times (this is a bit long in order to have proper estimate of the average times)
begin
    BenchmarkTools.DEFAULT_PARAMETERS.seconds = 120 #lower this value to speed up the benchmark (and loose some precision on the time estimates)
    #n = Int(1e6) #number of nodes
    n = Int(1e5) #number of nodes
    k = 2 #number of classes
    # "strong community structure":
    s = 20
    easiness = 4

    G, gr_truth = generate_SBM(n, k, s, easiness)
    y = rand(n)

    q = 1.

    # In the benchmark environment, dollars are added such that the computation time does not include the time to go fetch the variables in memory
    # You can also try without the $, it does not change the result much
    bench_tilde = @benchmark xtilde = smooth_rf($G,q,$y;nrep=1,variant=1).est
    bench_bar = @benchmark xbar = smooth_rf($G,q,$y;nrep=1,variant=2).est

    L = laplacian_matrix(G)
    bench_simple_multiplication = @benchmark aux = $L * $y
end
