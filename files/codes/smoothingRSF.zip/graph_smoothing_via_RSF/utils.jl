

# get community structure given a few labels (stored in Y)
function ssl(G,Y,mu,sigma;method="exact",nrep=10)
    #has_label = sum(Y,dims=1) .!= 0
    d = degree(G)
    D_sm1 = spdiagm(0 => d.^(sigma-1))
    D_1ms = spdiagm(0 => d.^(1-sigma))
    q = (mu/2) .* d

    Z = D_sm1 * Y

    if (method=="exact")
        S = D_1ms * (smooth(G,q,Z))
    else
        Zbar = repeat(mean(Z, dims=1), outer=size(Z,1))
        Δ = Z - Zbar
        if (method=="xtilde")
            S = D_1ms * (Zbar + smooth_rf(G,q,Δ;nrep=nrep,variant=1).est)
        elseif (method=="xbar")
            S = D_1ms * (Zbar + smooth_rf(G,q,Δ;nrep=nrep,variant=2).est)
        end
    end
    cluster_ind = zeros(Int64, nv(G))
    k = size(Y,2)
    exaequo = 0
    for i=1:nv(G)
        if StatsBase.std(S[i,:]) == 0 #that happens if q is too large or m is too small
            cluster_ind[i] = rand(1:k)
            exaequo += 1
        else
            cluster_ind[i] = argmax(S[i,:])
        end
    end
    return cluster_ind, exaequo
end

# given a ground truth where the first n/k nodes are in class 1, the n/k next are in class 2, etc up to class k: generate Y a partial ground truth labeling of the nodes
function generate_Y(n,k,m)
    labeled_nodes = zeros(m, k)
    siz_bl = Int(n/k)
    for kk=0:k-1
        labeled_nodes[:,kk+1] = StatsBase.sample((siz_bl*kk + 1:siz_bl*(kk+1)), m; replace=false)
    end
    labeled_nodes = convert(Array{Int64}, labeled_nodes)

    Y = zeros((n,k))
    for kk=1:k
        Y[labeled_nodes[:,kk],kk] .= 1
    end
    return Y
end

# generate a SBM graph with parameters s, the average degree, and easiness, the easiness of the
# community recovery problem.
# easiness=1 is the theoretcial threshold in the case of two equal size communities:
# for easiness<1, no algorithm can recover community structure;
# for easiness>1, it becomes possible.
# The larger easiness, the easier the recovery.
# (see Decelle et al., "Asymptotic analysis of the stochastic block model for modular networks
# and its algorithmic applications", PRE 2011 for more details)
function generate_SBM(n, k, s, easiness)

    εc = (s-sqrt(s)) / (s + sqrt(s)*(k-1))
    ε = εc / easiness

    q2 = (ε*s*k) / (n-k+ε*n*(k-1))
    q1 = q2 / ε

    cint = ceil((n/k -1) * q1)
    cout = floor((n - n/k) * q2)

    G = stochastic_block_model(cint, cout, repeat([Int(n/k)], inner=k))
    gr_truth = repeat(1:k, inner=Int64(n/k))
    @assert(is_connected(G))
    return G, gr_truth
end
